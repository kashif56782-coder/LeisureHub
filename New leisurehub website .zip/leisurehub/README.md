# LeisureHub – Full-stack movie and event ticket booking website

This project follows the supplied black book architecture: React.js frontend, Node.js/Express REST API and MongoDB database.

## Design
Clean light-grey and white layout, black navigation and orange booking buttons inspired by the supplied reference. No poster photographs or decorative images are used. Movie listings use real film titles: Jawan, Dangal, 3 Idiots, Chhaava, Saiyaara and Zindagi Na Milegi Dobara. These are sample catalogue entries, not confirmation of current local cinema showtimes.

## Features
- Customer registration, login, logout and profile update
- Browse/search movies and events and view listing details
- Ticket booking with date, show time, quantity, total and booking ID
- My Bookings status and history
- Admin dashboard to manage movies, events, users and bookings
- Password hashing, JWT authentication and admin authorization
- MongoDB persistence; no real payment gateway

## Free deployment (GitHub + Render + MongoDB Atlas)
1. Create a free GitHub account and repository.
2. Upload this ZIP file itself; keep its name `LeisureHub_Website_Source.zip`.
3. Create a free MongoDB Atlas cluster and database user. For a student demo, add `0.0.0.0/0` to the Atlas IP access list. Copy the Node.js connection string and replace its username/password placeholders.
4. Create a Render Web Service and connect the GitHub repository.
5. Build Command: `unzip -o LeisureHub_Website_Source.zip -d . && cd leisurehub && npm install && npm run install:all && npm run build`
6. Start Command: `cd leisurehub && npm start`
7. Add `MONGODB_URI`, `JWT_SECRET`, `ADMIN_EMAIL` and `ADMIN_PASSWORD` as Render environment variables.
8. Choose the Free instance plan and deploy.

Movie and event seed records are inserted only when their MongoDB collections are empty. If you already used an earlier version of this ZIP, old demo movie records may remain. Use a fresh empty database or delete the old movie records before first running this version.

## Admin account
If environment variables are not supplied, development defaults are `admin@leisurehub.com` / `Admin@123`. For deployment, set your own `ADMIN_EMAIL` and `ADMIN_PASSWORD` before first start. Do not share admin credentials.

## Notes
- Booking is a project/demo confirmation, not a real payment transaction.
- Render free services may sleep when inactive and take time to wake.
- The open Atlas IP rule above is for a student demo only; use restricted access for production.
