import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {User,Movie,Event,Booking} from './models.js';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const clientDist = path.resolve(__dirname, '../../client/dist');
dotenv.config();
const app=express(); app.use(cors()); app.use(express.json());
const SECRET=process.env.JWT_SECRET||'leisurehub-development-secret-change-me';
const auth=async(req,res,next)=>{try{const token=(req.headers.authorization||'').replace('Bearer ','');if(!token) return res.status(401).json({message:'Please log in first'});req.user=jwt.verify(token,SECRET);const u=await User.findById(req.user.id);if(!u||!u.is_active)return res.status(401).json({message:'Account unavailable'});req.account=u;next()}catch{return res.status(401).json({message:'Session expired. Please log in again.'})}};
const admin=(req,res,next)=>req.account?.role==='admin'?next():res.status(403).json({message:'Administrator access required'});
const tokenFor=u=>jwt.sign({id:u._id,role:u.role},SECRET,{expiresIn:'7d'});
app.get('/api/health',(req,res)=>res.json({status:'ok',app:'LeisureHub'}));
app.post('/api/auth/register',async(req,res)=>{try{const {name,email,password,phone}=req.body;if(!name||!email||!password||password.length<6)return res.status(400).json({message:'Enter name, valid email and password (at least 6 characters)'});if(await User.findOne({email:email.toLowerCase()}))return res.status(409).json({message:'Email already registered'});const u=await User.create({name,email,password:await bcrypt.hash(password,10),phone});res.status(201).json({token:tokenFor(u),user:{id:u._id,name:u.name,email:u.email,phone:u.phone,role:u.role}})}catch(e){res.status(500).json({message:'Could not register account'})}});
app.post('/api/auth/login',async(req,res)=>{const {email,password}=req.body;const u=await User.findOne({email:(email||'').toLowerCase()});if(!u||!u.is_active||!(await bcrypt.compare(password||'',u.password)))return res.status(401).json({message:'Incorrect email or password'});res.json({token:tokenFor(u),user:{id:u._id,name:u.name,email:u.email,phone:u.phone,role:u.role}})});
app.get('/api/auth/me',auth,(req,res)=>res.json({id:req.account._id,name:req.account.name,email:req.account.email,phone:req.account.phone,role:req.account.role}));
app.put('/api/users/profile',auth,async(req,res)=>{const {name,phone}=req.body;if(!name?.trim())return res.status(400).json({message:'Name is required'});const u=await User.findByIdAndUpdate(req.account._id,{name:name.trim(),phone},{new:true});res.json({id:u._id,name:u.name,email:u.email,phone:u.phone,role:u.role})});
app.get('/api/movies',async(req,res)=>{const q=(req.query.search||'').trim();res.json(await Movie.find({is_active:true,...(q?{title:{$regex:q,$options:'i'}}:{})}).sort({createdAt:-1}))});
app.get('/api/movies/:id',async(req,res)=>{const x=await Movie.findOne({_id:req.params.id,is_active:true});if(!x)return res.status(404).json({message:'Movie not found'});res.json(x)});
app.get('/api/events',async(req,res)=>{const q=(req.query.search||'').trim();res.json(await Event.find({is_active:true,...(q?{title:{$regex:q,$options:'i'}}:{})}).sort({createdAt:-1}))});
app.get('/api/events/:id',async(req,res)=>{const x=await Event.findOne({_id:req.params.id,is_active:true});if(!x)return res.status(404).json({message:'Event not found'});res.json(x)});
app.post('/api/bookings',auth,async(req,res)=>{try{const {item_type,item,booking_date,show_time,quantity}=req.body;if(!['movie','event'].includes(item_type)||!item||!booking_date||!Number.isInteger(Number(quantity))||Number(quantity)<1||Number(quantity)>10)return res.status(400).json({message:'Check your booking details. Quantity must be 1–10.'});const Model=item_type==='movie'?Movie:Event;const listing=await Model.findOne({_id:item,is_active:true});if(!listing)return res.status(404).json({message:'This listing is no longer available'});const amount=Number(listing.price)*Number(quantity);const b=await Booking.create({booking_id:'LH'+Date.now().toString().slice(-9),user:req.account._id,item_type,item,item_title:listing.title,booking_date,show_time:show_time||listing.time||'As listed',quantity:Number(quantity),total_amount:amount,customer_name:req.account.name});res.status(201).json(b)}catch(e){res.status(500).json({message:'Booking could not be completed'})}});
app.get('/api/bookings/my',auth,async(req,res)=>res.json(await Booking.find({user:req.account._id}).sort({createdAt:-1})));
app.get('/api/bookings/:id',auth,async(req,res)=>{const b=await Booking.findOne({booking_id:req.params.id,user:req.account._id});if(!b)return res.status(404).json({message:'Booking not found'});res.json(b)});
app.get('/api/admin/movies',auth,admin,async(req,res)=>res.json(await Movie.find().sort({createdAt:-1})));
app.post('/api/admin/movies',auth,admin,async(req,res)=>{try{const x=await Movie.create(req.body);res.status(201).json(x)}catch(e){res.status(400).json({message:'Movie title is required'})}});
app.put('/api/admin/movies/:id',auth,admin,async(req,res)=>res.json(await Movie.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true})));
app.delete('/api/admin/movies/:id',auth,admin,async(req,res)=>{await Movie.findByIdAndUpdate(req.params.id,{is_active:false});res.json({message:'Movie removed'})});
app.get('/api/admin/events',auth,admin,async(req,res)=>res.json(await Event.find().sort({createdAt:-1})));
app.post('/api/admin/events',auth,admin,async(req,res)=>{try{const x=await Event.create(req.body);res.status(201).json(x)}catch(e){res.status(400).json({message:'Event title is required'})}});
app.put('/api/admin/events/:id',auth,admin,async(req,res)=>res.json(await Event.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true})));
app.delete('/api/admin/events/:id',auth,admin,async(req,res)=>{await Event.findByIdAndUpdate(req.params.id,{is_active:false});res.json({message:'Event removed'})});
app.get('/api/admin/users',auth,admin,async(req,res)=>res.json(await User.find().select('-password').sort({createdAt:-1})));
app.put('/api/admin/users/:id',auth,admin,async(req,res)=>{if(String(req.account._id)===req.params.id)return res.status(400).json({message:'You cannot deactivate your own account'});const u=await User.findByIdAndUpdate(req.params.id,{is_active:!!req.body.is_active},{new:true}).select('-password');res.json(u)});
app.get('/api/admin/bookings',auth,admin,async(req,res)=>res.json(await Booking.find().populate('user','name email').sort({createdAt:-1})));
app.put('/api/admin/bookings/:id',auth,admin,async(req,res)=>{const allowed=['Confirmed','Cancelled','Completed'];if(!allowed.includes(req.body.status))return res.status(400).json({message:'Invalid status'});res.json(await Booking.findByIdAndUpdate(req.params.id,{status:req.body.status},{new:true}))});
// Serve the built React website from the same Express service in production.
app.use(express.static(clientDist));
app.get('*',(req,res)=>res.sendFile(path.join(clientDist,'index.html')));

async function seed(){const email=(process.env.ADMIN_EMAIL||'admin@leisurehub.com').toLowerCase();if(!await User.findOne({email}))await User.create({name:'LeisureHub Admin',email,password:await bcrypt.hash(process.env.ADMIN_PASSWORD||'Admin@123',10),role:'admin'});if(await Movie.countDocuments()===0)await Movie.insertMany([
{title:'Jawan',genre:'Action',duration:'2h 49m',language:'Hindi',rating:'U/A',description:'An action thriller featuring a man driven by a personal mission to correct social wrongs.',price:180},
{title:'Dangal',genre:'Sports Drama',duration:'2h 41m',language:'Hindi',rating:'U',description:'A former wrestler trains his daughters to become competitive wrestlers.',price:160},
{title:'3 Idiots',genre:'Comedy Drama',duration:'2h 50m',language:'Hindi',rating:'U/A',description:'Three engineering students challenge the pressure and expectations of the education system.',price:150},
{title:'Chhaava',genre:'Historical Action',duration:'2h 35m',language:'Hindi',rating:'U/A',description:'A historical drama based on the life of Chhatrapati Sambhaji Maharaj.',price:200},
{title:'Saiyaara',genre:'Romantic Drama',duration:'2h 26m',language:'Hindi',rating:'U/A',description:'A romantic musical drama about love, ambition and the challenges faced by two young people.',price:180},
{title:'Zindagi Na Milegi Dobara',genre:'Adventure Drama',duration:'2h 33m',language:'Hindi',rating:'U/A',description:'Three friends take a road trip through Spain and rediscover friendship and life.',price:170}
]);if(await Event.countDocuments()===0)await Event.insertMany([{title:'Live Music Night',category:'Music',date:'2026-12-15',time:'7:00 PM',venue:'City Arena',description:'An evening of live music and performances.',image:'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=900',price:350},{title:'Comedy Special',category:'Comedy',date:'2026-12-20',time:'6:30 PM',venue:'The Grand Hall',description:'A fun night of stand-up comedy.',image:'https://images.unsplash.com/photo-1527224857830-43a7acc85260?w=900',price:250}])}
const start=async()=>{try{if(!process.env.MONGODB_URI){console.error('Set MONGODB_URI in Secrets before starting.');process.exit(1)}await mongoose.connect(process.env.MONGODB_URI);await seed();const port=process.env.PORT||5000;app.listen(port,'0.0.0.0',()=>console.log(`LeisureHub API running on ${port}`))}catch(e){console.error(e);process.exit(1)}};start();
